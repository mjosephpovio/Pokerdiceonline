package com.example.pokerdice

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PokerDiceGame()
        }
    }
}

val diceFaces = listOf("9", "10", "J", "Q", "K", "A")

@Composable
fun PokerDiceGame() {
    var player1Score by remember { mutableStateOf(0) }
    var player2Score by remember { mutableStateOf(0) }
    var currentPlayer by remember { mutableStateOf(1) }
    var player1Dice by remember { mutableStateOf(emptyList<String>()) }
    var player2Dice by remember { mutableStateOf(emptyList<String>()) }
    var player1Hand by remember { mutableStateOf("") }
    var player2Hand by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var roundOngoing by remember { mutableStateOf(true) }
    var doublePoints by remember { mutableStateOf(1) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceAround
    ) {
        Text("Poker Dice", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Player 1", fontWeight = FontWeight.Bold)
                Text("Score: $player1Score")
                Text(player1Dice.joinToString(" "))
                Text(player1Hand)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Player 2", fontWeight = FontWeight.Bold)
                Text("Score: $player2Score")
                Text(player2Dice.joinToString(" "))
                Text(player2Hand)
            }
        }

        Text("$result", fontWeight = FontWeight.SemiBold, fontSize = 20.sp)

        Button(onClick = {
            if (roundOngoing) {
                val roll = List(5) { diceFaces.random() }
                val handName = evaluateHand(roll)
                if (currentPlayer == 1) {
                    player1Dice = roll
                    player1Hand = handName
                    currentPlayer = 2
                } else {
                    player2Dice = roll
                    player2Hand = handName
                    val winner = compareHands(player1Dice, player2Dice)
                    val points = doublePoints * when (evaluateHandPoints(player1Dice.takeIf { winner == 1 } ?: player2Dice)) {
                        4 -> 2
                        5 -> 3
                        else -> 1
                    }
                    when (winner) {
                        1 -> {
                            player1Score += points
                            result = "Player 1 wins the round (+$points)!"
                            doublePoints = 1
                        }
                        2 -> {
                            player2Score += points
                            result = "Player 2 wins the round (+$points)!"
                            doublePoints = 1
                        }
                        else -> {
                            result = "Tie! Next round is double or nothing!"
                            doublePoints *= 2
                        }
                    }
                    roundOngoing = false
                }
            } else {
                player1Dice = emptyList()
                player2Dice = emptyList()
                player1Hand = ""
                player2Hand = ""
                result = ""
                currentPlayer = 1
                roundOngoing = true
            }
        }) {
            Text(if (roundOngoing) "Roll for Player $currentPlayer" else "Next Round")
        }
    }
}

fun evaluateHand(dice: List<String>): String {
    val counts = dice.groupingBy { it }.eachCount().values.sortedDescending()
    return when {
        counts == listOf(5) -> "Five of a Kind"
        counts == listOf(4, 1) -> "Four of a Kind"
        counts == listOf(3, 2) -> "Full House"
        counts == listOf(3, 1, 1) -> "Three of a Kind"
        counts == listOf(2, 2, 1) -> "Two Pair"
        counts == listOf(2, 1, 1, 1) -> "One Pair"
        else -> "High Card"
    }
}

fun evaluateHandPoints(dice: List<String>): Int {
    val counts = dice.groupingBy { it }.eachCount().values.sortedDescending()
    return when {
        counts == listOf(5) -> 5
        counts == listOf(4, 1) -> 4
        counts == listOf(3, 2) -> 3
        counts == listOf(3, 1, 1) -> 2
        counts == listOf(2, 2, 1) -> 1
        counts == listOf(2, 1, 1, 1) -> 0
        else -> -1
    }
}

fun compareHands(dice1: List<String>, dice2: List<String>): Int {
    val p1 = evaluateHandPoints(dice1)
    val p2 = evaluateHandPoints(dice2)
    return when {
        p1 > p2 -> 1
        p2 > p1 -> 2
        else -> 0 // tie
    }
}
